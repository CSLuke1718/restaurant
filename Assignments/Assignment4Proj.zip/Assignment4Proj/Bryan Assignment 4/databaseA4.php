<!DOCTYPE html>
<!-- Fig. 19.16: databaseA4.php -->
<!-- Querying a database and displaying the results. -->
<html>
   <head>
      <meta charset = "utf-8">
      <title>Search Results</title>
   <style type = "text/css">
         body  { font-family: sans-serif; background-color: lightyellow; }
         table { background-color: lightblue; border-collapse: collapse; border: 1px solid gray; }
         td    { padding: 5px; }
         tr:nth-child(odd) {background-color: white; } <!-- alternate colors for different rows. -->
   </style>
   </head>
   <body>
      <?php
		$select="*";
        $select = $_POST["select"]; // creates variable $select
		echo "$select";
        if ($select=="*")
			{$query = "SELECT " . $select . " FROM rentalwcost";} // distinct added if * not selected
		else
			{$query = "SELECT DISTINCT(" . $select . ") FROM rentalwcost";}

         // Connect to MySQL
         if ( !( $database = mysqli_connect( "localhost",
            "bonnie", "bon", "BryanCSSE370A4" ) ) )
            die( "Could not connect to database </body></html>" );

         // open Products database
         if ( !mysqli_select_db( $database, "BryanCSSE370A4" ) )
            die( "Could not open products database </body></html>" );

         // query Products database
         if ( !( $result = mysqli_query( $database, $query ) ) )
         {
            print( "<p>Could not execute query!</p>" );
            die( mysqli_error() . "</body></html>" );
         } // end if

         mysqli_close( $database );
      ?><!-- end PHP script -->
      <table>
        <thead>Results of "SELECT <?php print( "$select" ) ?> FROM rentalwcost"
			<?php if ($select != "*") print (": Distinct ". "$select"); ?>
		</thead>
         <?php
            // fetch each record in result set
            while ( $row = mysqli_fetch_row( $result ) )
            {
               // build table to display results
               print( "<tr>" );

               foreach ( $row as $value )
                  print( "<td>$value</td>" );

               print( "</tr>" );
            } // end while
         ?><!-- end PHP script -->
      </table>
      <p>Your search yielded
         <?php print( mysqli_num_rows( $result ) ) ?> results.</p>
      <p>Please email comments to <a href = "mailto:brb7@students.fresno.edu">
            FPU, University</a></p>
   </body>
</html>

<!--
**************************************************************************
* (C) Copyright 1992-2008 by Deitel & Associates, Inc. and               *
* Pearson Education, Inc. All Rights Reserved.                           *
*                                                                        *
* DISCLAIMER: The authors and publisher of this book have used their     *
* best efforts in preparing the book. These efforts include the          *
* development, research, and testing of the theories and programs        *
* to determine their effectiveness. The authors and publisher make       *
* no warranty of any kind, expressed or implied, with regard to these    *
* programs or to the documentation contained in these books. The authors *
* and publisher shall not be liable in any event for incidental or       *
* consequential damages in connection with, or arising out of, the       *
* furnishing, performance, or use of these programs.                     *
**************************************************************************
-->