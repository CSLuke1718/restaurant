<!DOCTYPE html>
<!-- Fig. 19.16: database.php -->
<!-- Querying a database and displaying the results. -->
<html>
   <head>
      <meta charset = "utf-8">
      <title>Search Results</title>
   <style type = "text/css">
         body  { font-family: sans-serif; background-color: lightyellow; }
         table { background-color: lightblue; border-collapse: collapse; border: 1px solid gray; }
         td    { padding: 5px; }
         tr:nth-child(odd) {background-color: white; } <!-- alternate colors for different rows. -->
   </style>
   </head>
   <body>
      <?php
         $select = $_POST["select"]; // creates variable $select

         // build SELECT query
         if($select =='*')
			{$query = "SELECT ".$select." FROM rentalwcost";}
		else
			{$query = "SELECT DISTINCT(".$select.") FROM rentalwcost";}

         // Connect to MySQL
         if ( !( $database = mysqli_connect( "localhost",
            "bonnie", "bon", "LukeCSSE370A4" ) ) )
            die( "Could not connect to database </body></html>" );

         // open LukeCSSE370A4 database
         if ( !mysqli_select_db( $database, "LukeCSSE370A4" ) )
            die( "Could not open Luke database </body></html>" );

         // query LukeCSSE370A4 database
         if ( !( $result = mysqli_query( $database, $query ) ) )
         {
            print( "<p>Could not execute query!</p>" );
            die( mysqli_error() . "</body></html>" );
         } // end if

         mysqli_close( $database );
      ?><!-- end PHP script -->
      <table>
         <thead>Results of "SELECT <?php print( "$select" ) ?> FROM rentalwcost"
		 <?php if($select != "*") print(": Distinct "."$select"); ?>
		 </thead>
         <?php
            // fetch each record in result set
            while ( $row = mysqli_fetch_row( $result ) )
            {
               // build table to display results
               print( "<tr>" );

               foreach ( $row as $value )
                  print( "<td>$value</td>" );

               print( "</tr>" );
            } // end while
         ?><!-- end PHP script -->
      </table>
      <p>Your search yielded
         <?php print( mysqli_num_rows( $result ) ) ?> results.</p>
      <p>Please email comments to <a href = "mailto:lcs5@students.fresno.edu">
            FPU</a></p>
   </body>
</html>