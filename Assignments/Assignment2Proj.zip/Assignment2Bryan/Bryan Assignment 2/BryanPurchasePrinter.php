<!DOCTYPE html>

<!-- Bryan Banuelos -->
<html>
<?php
   $NRUN = 10; $INKPRICE=78; $LASERPRICE=359; $FAXPRICE=489; $NMAX=20; $NMIN=1; $NDISC=10; 
   ?><!-- end PHP script -->
   <head>
   <!--utf-8 encodes more than one million valid character codes in Unicode-->
      <meta charset = "utf-8">
      <title>Assignment 2 in TABLE FORM</title>
   </head>
   <body>
      <!-- print variable name�s value -->
      <h1>Total price of printers</h1>
	<table border = "1">
		<th><h2> Printer Prices </h2></th>
		<th><h2> Inkjet printers <?php echo " price each is".$INKPRICE ?> </h2></th>
		<th><h2> LaserJet printers <?php echo " price each is ".$LASERPRICE ?></h2></th>
		<th><h2> Fax printers <?php echo " price each is ".$FAXPRICE ?></h2></th>
		<?php
		for($i=0; $i<$NRUN; $i++) {
			$ninkjet = rand($NMIN, $NMAX); $nlaserjet = rand($NMIN, $NMAX); $nfax = rand($NMIN, $NMAX);
		if($ninkjet<=$NDISC) {$inkdiscount=0;} else{$inkdiscount=0.05;}
		if($nlaserjet<=$NDISC) {$laserdiscount=0.02;} else{$laserdiscount=0.07;}
		if($nfax<=$NDISC) {$faxdiscount=.03;} else{$faxdiscount=.09;}
		
		$totalink=$ninkjet*(1-$inkdiscount)*$INKPRICE;
		$totallaser=$nlaserjet*(1-$laserdiscount)*$LASERPRICE;
		$totalfax=$nfax*(1-$faxdiscount)*$FAXPRICE;
		echo "<tr> <td colspan='4'>Program run = ".($i+1)."</td></tr>";
		echo "<tr><td> #printer purchased: </td>"; echo "<td>$ninkjet</td>"; echo "<td>$nlaserjet</td>"; echo "<td>$nfax</td>";
		echo "</tr>"; echo "<tr>";
		echo "<td> discount is </td>"; echo "<td>".($inkdiscount*100)."%</td>"; echo "<td>".($laserdiscount*100)."%</td>"; echo "<td>".($faxdiscount*100)."%</td>";
		echo "</tr>"; echo "<tr>";
		echo "<td> total price is </td>"; echo "<td>$".$totalink." </td>"; echo "<td>$".$totallaser." </td>"; echo "<td>$".$totalfax." </td>"; echo "</tr>";
		} //end for 
		?>
		
   </body>
</html>

