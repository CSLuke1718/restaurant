<!DOCTYPE html>

<!-- Luke Smith, Assignment 2 -->

<html>
<?php //Luke Smith
	$INKJET = 78;
	$LASERJET = 359;
	$FAXPRINTER = 489;
	$MAX = 20;
	$MIN = 1;
	$NRUN = 10;
?>
	<head>
		<title>Assignment 2</title>
	</head>
	<body>
		<h1>Total Price of Printers</h1>
		<table border="1">
			<th><h2>Printer Prices</h2></th>
			<th><h2>InkJet Printers, <?php echo "price each $".$INKJET?></h2></th>
			<th><h2>LaserJet Printers, <?php echo "price each $".$LASERJET?></h2></th>
			<th><h2>Fax Printers, <?php echo "price each $".$FAXPRINTER?></h2></th>
			<?php
				for($i=0; $i < $NRUN; $i++) {		//for loop to print out table
					$nInkJet = rand($MIN, $MAX);
					$nLaserJet = rand($MIN, $MAX);
					$nFaxPrinter = rand($MIN, $MAX);
					if($nInkJet > 10) {$IJdiscount = 0.05;} else {$IJdiscount = 0;};
					if($nLaserJet > 10) {$LJdiscount = 0.07;} else {$LJdiscount = 0.02;};
					if($nFaxPrinter > 10) {$FPdiscount = 0.09;} else {$FPdiscount = 0.03;};
					$IJcost = $nInkJet*$INKJET*(1 - $IJdiscount);
					$LJcost = $nLaserJet*$LASERJET*(1 - $LJdiscount);
					$FPcost = $nFaxPrinter*$FAXPRINTER*(1 - $FPdiscount);
					echo "<tr><td colspan='4'>Program run ".($i+1)."</td></tr>";
					echo "<tr><td>Num Printers Purchased:</td><td>".$nInkJet."</td><td>".$nLaserJet."</td><td>".$nFaxPrinter."</td></tr>";
					echo "<tr><td>Discount:</td><td>".($IJdiscount*100)."%</td><td>".($LJdiscount*100)."%</td><td>".($FPdiscount*100)."%</td></tr>";
					echo "<tr><td>Total Cost:</td><td>$".$IJcost."</td><td>$".$LJcost."</td><td>$".$FPcost."</td></tr>";
				} //end forloop
			?>
	</body>
</html>
	


