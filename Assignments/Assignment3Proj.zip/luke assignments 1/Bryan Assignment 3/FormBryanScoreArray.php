<!DOCTYPE html>

<!--Bryan Assignment 3-->

<html>
<head>
	<meta charset="utf-8">
	<title>Form Results</title>
</head>
<body>
	<h1>Hello! Welcome, <?php print($_POST["name"])?>.</h1>
		<?php 	$NUMSCORESLOTS = 5;
				
				$score[1] = intval ($_POST["score1"]);
				$score[2] = intval ($_POST["score2"]);
				$score[3] = intval ($_POST["score3"]);
				$score[4] = intval ($_POST["score4"]);
				$score[5] = intval ($_POST["score5"]);
				$numscores = ($_POST["NumScores"]);
				
				$sum = 0;
				$minscore = 100;
				$maxscore = 0;
				$kcount = 0;
				for($i=1; $i<$NUMSCORESLOTS;++$i){
					if($score[$i] > 0){
						++$kcount;
						$sum = $sum + $score[$i];
						if($score[$i]>$maxscore){
							$maxscore = $score[$i];
						} if($score[$i]<$minscore){
							$minscore = $score[$i];
						}
						
					}
				}
				$average = (float)$sum / $numscores;
			?>
	<h1>Number of scores selected is 	<?php print($numscores)?>.</h1>
	<h1>Number of entered scores is 	<?php print($kcount)?>.</h1>
	<h1>Maximum score is 				<?php print($maxscore)?>.</h1>
	<h1>Minimum score is				<?php print($minscore)?>.</h1>
	<h1>Average score is 				<?php print($average)?>.</h1>
	<table border="1">
	<thead><h1>Entered scores are:</h1></thead>
	<tr>
		<?php 
			for($i=1; $i<=$NUMSCORESLOTS; ++$i){
				if($score[$i] > 0){
					echo "<td><h1>$score[$i]</h1></td>";
				}
			}
		?>
	</tr>

</body>
</html>