<!DOCTYPE html>

<!--Bryan Assignment 3-->

<html>
<head>
	<meta charset = "utf-8">
	<title>Average Score Form</title>
</head>
<body>
	<h1>Score average: Maximum of 3 scores can be entered for averaging</h1>
	<form method="post" action="FormLukeScoreArray.php">
		<div><label>Enter Name:</label><input type="text" name="name"></div>
		<br>
		<div><label>Total number of scores entered:</label>
		<select name="NumScores" id="NumScores" required>
			<option value="1" selected="selected">1</option>
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
		</select></div><br>
		<div><label>Enter scores between 0 and 100. (Fill up highest rows first!)</label></div>
		<div><label>Enter score 1:</label><input type="number" name="score1" value="0" min="0" max="100"></div>
		<div><label>Enter score 2:</label><input type="number" name="score2" value="0" min="0" max="100"></div>
		<div><label>Enter score 3:</label><input type="number" name="score3" value="0" min="0" max="100"></div>
		<div><label>Enter score 4:</label><input type="number" name="score4" value="0" min="0" max="100"></div>
		<div><label>Enter score 5:</label><input type="number" name="score5" value="0" min="0" max="100"></div>
		<br>
		<div><label>Submit Scores:</label><input type="submit" name="submit" value="Submit Scores"></div>
	</form>
</body>
</html>